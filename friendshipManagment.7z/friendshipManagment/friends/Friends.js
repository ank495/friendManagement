var mongoose = require('mongoose');  
var FriendSchema = new mongoose.Schema({    
    username: String,
    friends: [String],
});
mongoose.model('Friends', FriendSchema);
var SubscribeSchema = new mongoose.Schema({
    requestor:String,
    target:String
})

module.exports = mongoose.model('Friends');