var mongoose = require('mongoose');  
var SubscribeSchema = new mongoose.Schema({
    requestor:String,
    target:String
})
mongoose.model('Subscribe', SubscribeSchema);
module.exports = mongoose.model('Subscribe');