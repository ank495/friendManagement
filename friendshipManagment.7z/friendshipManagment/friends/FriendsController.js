var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');

var VerifyToken = require(__root + 'auth/VerifyToken');

router.use(bodyParser.urlencoded({ extended: false }));
router.use(bodyParser.json());
var Friends = require('./Friends');
var Subscribe = require('./Subscribe');

// CREATES THE CONNECTION BETWEEN TWO EMAIL ADDRESS
router.post('/createConnection', VerifyToken,function (req, res) {
    Friends.create({
          friends: req.body.friends
        }, 
        function (err, user) {
            if (err) return res.status(500).send("There was a problem in adding friends.");
            res.status(200).send(JSON.stringify({Success:true}));
        });
});

// RETURNS ALL THE FRIENDS FOR A PARTICULAR EMAIL ADDRESS
router.post('/findFriends', VerifyToken,function (req, res) {
	  Friends.findOne({friends:req.body.username}, function (err, friend) {
        if (err) return res.status(500).send("There was a problem finding the Friends.");
        let response = friend.friends;
        response = response.filter(function(item){
            return item != req.body.username
        });
        console.log(response);
        res.status(200).send(JSON.stringify({success:true,friends:response,count:1}));
    });
});

// RETURNS COMMON FRIENDLIST BETWEEN TWO EMAIL ADDRESS
router.post('/commonFriends', function (req, res) {
    var friendsOne;
    var friendsTwo
    Friends.findOne({friends:req.body.friends[0]}, function (err, friend) {
        if (err) return res.status(500).send("There was a problem finding the common friends.");
        friendsOne = friend.friends;
        friendsOne = friendsOne.filter(function(item){
            for(var i=0;i<req.body.friends.length;i++){
                return (item != req.body.friends[i]);
            }
        });
        
    });
});


// SUBSCRIBE UPDATES FROM EMAIL ADDRESS
router.post('/subscribes', function (req, res) {
    Subscribe.create({
        requestor:req.body.requestor,
        target:req.body.target
      }, 
      function (err, user) {
          if (err) return res.status(500).send("There was a problem in subscribing friends.");
          res.status(200).send(JSON.stringify({Success:true}));
      });
});

// BLOCK UPDATES FROM EMAIL ADDRESS
router.get('/blockUpdates/:emailId', function (req, res) {
    Books.findByIdAndRemove(req.params.id, function (err, books) {
        if (err) return res.status(500).send("There was a problem deleting the book.");
        res.status(200).send("book: "+ books.title +" was deleted.");
    });
});



module.exports = router;